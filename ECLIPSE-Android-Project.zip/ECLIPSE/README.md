# ECLIPSE — Native Android Music Player

ECLIPSE is a Kotlin Android project using Media3 ExoPlayer and MediaSessionService. The current initial implementation includes a dark emerald player screen, local audio selection through Android's document picker, queueing selected tracks, play/pause/previous/next, seek, shuffle, repeat, playback-speed selection, and a native media-session service.

## Honest build status

**This source has not been compiled or device-tested in the current environment.** Android SDK, Gradle, and ADB were not available here. The included GitHub Actions workflow is intended to build the debug APK in a configured CI environment. Do not treat this archive as a verified APK.

This is the first implementation milestone, not yet the complete master specification. Artwork extraction and caching, persistent playlists/favorites, full library screens, theme settings, equalizer, comprehensive automated tests, launcher artwork, and release signing still need implementation and verification.

## Build with Android Studio

1. Install Android Studio and Android SDK Platform 35 plus Build Tools 35.0.0.
2. Open this folder as an Android project.
3. Use JDK 17 for Gradle.
4. Allow Gradle to sync and download dependencies.
5. Run `testDebugUnitTest` and `assembleDebug`.
6. If successful, the debug APK should appear at `app/build/outputs/apk/debug/`.

The GitHub Actions workflow builds a debug APK on pushes to `main`, pull requests to `main`, and manual workflow runs. It does not create a signed release APK.

## Release signing

Do not commit signing credentials. Generate a release keystore locally using Android Studio's signing wizard or `keytool`, store it securely, and configure Gradle signing through local properties or protected CI secrets. Verify a release APK with Android SDK `apksigner verify --verbose --print-certs app-release.apk`.

## Package

`com.eclipse.music` (debug variant adds `.debug`). Minimum SDK 26, target SDK 35.
