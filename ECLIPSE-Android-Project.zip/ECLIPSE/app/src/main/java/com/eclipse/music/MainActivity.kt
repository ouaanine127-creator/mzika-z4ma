package com.eclipse.music

import android.content.ComponentName
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.setPadding
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.ExecutionException

class MainActivity : AppCompatActivity() {
    private var controller: MediaController? = null
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private lateinit var titleText: TextView
    private lateinit var artistText: TextView
    private lateinit var playButton: Button
    private lateinit var seekBar: SeekBar
    private lateinit var elapsedText: TextView
    private lateinit var durationText: TextView
    private lateinit var statusText: TextView
    private var userSeeking = false
    private var speedIndex = 1
    private val speeds = floatArrayOf(0.75f, 1.0f, 1.1f, 1.25f, 1.5f, 1.75f, 2.0f)

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (!uris.isNullOrEmpty()) {
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: SecurityException) { /* Some providers do not offer persistable grants. */ }
            }
            controller?.let { player ->
                val items = uris.map { MediaItem.fromUri(it) }
                player.setMediaItems(items, true)
                player.prepare()
                player.play()
                updateUi()
            } ?: run { statusText.text = "Connecting to audio engine… try selecting again in a moment." }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 10, 13)
        window.navigationBarColor = Color.rgb(7, 10, 13)
        buildInterface()
        connectPlayback()
        lifecycleScope.launch {
            while (true) {
                updateUi()
                delay(500)
            }
        }
    }

    private fun connectPlayback() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                controller?.addListener(object : Player.Listener {
                    override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) = updateUi()
                    override fun onIsPlayingChanged(isPlaying: Boolean) = updateUi()
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = updateUi()
                    override fun onPlaybackStateChanged(playbackState: Int) = updateUi()
                })
                updateUi()
            } catch (_: Exception) {
                statusText.text = "Audio engine unavailable. Reopen ECLIPSE and try again."
            }
        }, mainExecutor)
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(7,10,13), Color.rgb(8,19,23), Color.rgb(5,8,12)))
        }
        setContentView(root)
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = text("ECLIPSE", 19f, GREEN, true).apply { letterSpacing = 0.16f }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(button("LIBRARY") { pickAudio.launch(arrayOf("audio/*")) })
        root.addView(header, fullWidth())
        root.addView(text("YOUR PRIVATE SOUND UNIVERSE", 10f, MUTED, true).apply {
            letterSpacing = 0.18f; gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, dp(30)))

        val orb = EclipseOrb(this)
        root.addView(orb, LinearLayout.LayoutParams(dp(240), dp(240)).apply { topMargin = dp(20); bottomMargin = dp(24) })
        titleText = text("Nothing playing", 23f, WHITE, true).apply { gravity = Gravity.CENTER; maxLines = 2 }
        artistText = text("Choose music from your device", 14f, MUTED, false).apply { gravity = Gravity.CENTER; maxLines = 1 }
        root.addView(titleText, fullWidth())
        root.addView(artistText, LinearLayout.LayoutParams(-1, dp(32)))

        val timeRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        elapsedText = text("0:00", 11f, MUTED, false)
        durationText = text("0:00", 11f, MUTED, false)
        seekBar = SeekBar(this).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(GREEN)
            thumbTintList = android.content.res.ColorStateList.valueOf(GREEN)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(bar: SeekBar?) { userSeeking = true }
                override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) elapsedText.text = formatTime((progress / 1000L))
                }
                override fun onStopTrackingTouch(bar: SeekBar?) {
                    bar?.let { controller?.seekTo(it.progress.toLong()) }
                    userSeeking = false
                }
            })
        }
        timeRow.addView(elapsedText)
        timeRow.addView(seekBar, LinearLayout.LayoutParams(0, dp(42), 1f).apply { leftMargin = dp(8); rightMargin = dp(8) })
        timeRow.addView(durationText)
        root.addView(timeRow, fullWidth())

        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        controls.addView(button("|◀") { controller?.seekToPreviousMediaItem(); updateUi() })
        playButton = button("▶") { val p = controller ?: return@button; if (p.isPlaying) p.pause() else p.play(); updateUi() }
        controls.addView(playButton, LinearLayout.LayoutParams(dp(78), dp(58)).apply { leftMargin = dp(8); rightMargin = dp(8) })
        controls.addView(button("▶|") { controller?.seekToNextMediaItem(); updateUi() })
        root.addView(controls, LinearLayout.LayoutParams(-1, dp(70)))

        val extra = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        extra.addView(button("SHUFFLE") { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled; updateUi() } })
        extra.addView(button("REPEAT") { controller?.let { it.repeatMode = (it.repeatMode + 1) % 3; updateUi() } })
        extra.addView(button("SPEED") {
            val p = controller ?: return@button
            speedIndex = (speedIndex + 1) % speeds.size
            p.setPlaybackSpeed(speeds[speedIndex])
            statusText.text = "Playback speed ${String.format(Locale.US, "%.2f", speeds[speedIndex])}×"
        })
        root.addView(extra, fullWidth())
        val add = button("＋  ADD LOCAL MUSIC") { pickAudio.launch(arrayOf("audio/*")) }
        root.addView(add, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(18) })
        statusText = text("Offline playback · Your music stays on this device", 11f, MUTED, false).apply { gravity = Gravity.CENTER; maxLines = 2 }
        root.addView(statusText, LinearLayout.LayoutParams(-1, dp(44)))
    }

    private fun updateUi() {
        if (!::titleText.isInitialized) return
        val p = controller ?: return
        val metadata = p.mediaMetadata
        titleText.text = metadata.title?.toString() ?: "Nothing playing"
        artistText.text = metadata.artist?.toString() ?: if (p.mediaItemCount > 0) "Local audio" else "Choose music from your device"
        playButton.text = if (p.isPlaying) "Ⅱ" else "▶"
        val duration = p.duration.takeIf { it > 0 } ?: 0L
        if (!userSeeking) seekBar.progress = if (duration > 0) p.currentPosition.coerceAtMost(duration).toInt() else 0
        seekBar.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt().coerceAtLeast(1)
        elapsedText.text = formatTime(p.currentPosition / 1000)
        durationText.text = formatTime(duration / 1000)
        if (p.mediaItemCount == 0) statusText.text = "Offline playback · Your music stays on this device"
        else if (p.playbackState == Player.STATE_BUFFERING) statusText.text = "Preparing audio…"
        else if (p.playerError != null) statusText.text = "Could not play this file. Try another audio file."
        else statusText.text = "${if (p.isPlaying) "NOW PLAYING" else "READY"}  ·  ${p.mediaItemCount} track(s) in queue"
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false; setTextColor(if (label == "▶" || label == "Ⅱ") Color.BLACK else GREEN)
        background = GradientDrawable().apply { setColor(if (label == "▶" || label == "Ⅱ") GREEN else Color.rgb(15, 27, 31)); cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.rgb(28, 75, 62)) }
        setPadding(dp(12), dp(4), dp(12), dp(4)); setOnClickListener { action() }
    }
    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        gravity = Gravity.CENTER_VERTICAL
    }
    private fun fullWidth() = LinearLayout.LayoutParams(-1, dp(48))
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun formatTime(seconds: Long): String = String.format(Locale.US, "%d:%02d", seconds.coerceAtLeast(0) / 60, seconds.coerceAtLeast(0) % 60)

    override fun onDestroy() {
        controller?.release()
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }

    companion object {
        private const val GREEN = 0xFF10E89A.toInt()
        private const val WHITE = 0xFFF2F7F5.toInt()
        private const val MUTED = 0xFF879A9A.toInt()
    }
}

private class EclipseOrb(context: android.content.Context) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f; val cy = height / 2f; val r = minOf(width, height) * 0.34f
        paint.style = android.graphics.Paint.Style.FILL
        paint.shader = android.graphics.RadialGradient(cx, cy, r * 1.8f,
            intArrayOf(0x5533FFB0, 0x2233FFB0, 0x0033FFB0.toInt()), null, android.graphics.Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * 1.8f, paint)
        paint.shader = null; paint.color = 0xFF050A0C.toInt(); canvas.drawCircle(cx, cy, r, paint)
        paint.style = android.graphics.Paint.Style.STROKE; paint.strokeWidth = 3.5f
        paint.shader = android.graphics.LinearGradient(cx-r, cy-r, cx+r, cy+r, 0xFF0B7652.toInt(), 0xFF5CFFD0.toInt(), android.graphics.Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * 1.05f, paint)
        paint.shader = null; paint.strokeWidth = 1f; paint.color = 0x887BFFE0.toInt()
        canvas.drawArc(cx-r*1.25f, cy-r*1.25f, cx+r*1.25f, cy+r*1.25f, 215f, 85f, false, paint)
        paint.style = android.graphics.Paint.Style.FILL; paint.color = 0xFFE7FFF7.toInt()
        canvas.drawCircle(cx + r*0.72f, cy - r*0.78f, 3f, paint)
    }
}
