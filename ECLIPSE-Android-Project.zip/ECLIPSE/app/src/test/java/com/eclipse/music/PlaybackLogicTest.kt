package com.eclipse.music

import org.junit.Assert.assertEquals
import org.junit.Test

class PlaybackLogicTest {
    @Test fun supportedSpeedOptionsIncludeNormalSpeed() {
        val speeds = listOf(0.75f, 1.0f, 1.1f, 1.25f, 1.5f, 1.75f, 2.0f)
        assertEquals(7, speeds.size)
        assertEquals(1.0f, speeds[1])
    }
}
